# Political Bias Lab — Colab-Only, Zero-Budget Research Pipeline

A reproducible notebook-first framework for measuring entity-conditioned sentiment sensitivity, persona susceptibility, political-answer classification, and a Reasonable Pluralism mitigation protocol using open-weight language models.

## Why this revision exists

The first pilot exposed a measurement-validity problem: 1.5B–1.7B models could not reliably execute the more demanding tasks. The revised design therefore uses:

- **Qwen/Qwen2.5-7B-Instruct** — evaluated generator/model
- **mistralai/Mistral-7B-Instruct-v0.3** — evaluated generator/model
- **Qwen/Qwen2.5-14B-Instruct** — separate Phase 4 judge only
- 4-bit NF4 loading through bitsandbytes
- Google Colab only; no Kaggle, PostgreSQL, Docker, paid API, or local GPU requirement

The automated 14B judge is **secondary evidence**, not a substitute for blinded human evaluation.

## Architecture

```text
GitHub repository
      |
      v
Google Colab — 00 prepare data (CPU)
      |
      v
Google Drive / runs/<profile>-<gitsha>/
      |
      +--> Colab GPU — Qwen2.5-7B generator
      |
      +--> Colab GPU — Mistral-7B generator
      |
      +--> Colab GPU — Qwen2.5-14B blinded pairwise judge
      |
      +--> Colab CPU — statistics, capability gates, figures,
                       blinded human sheet, paper evidence bundle
```

Each profile is namespaced by Git commit SHA, preventing smoke/pilot/paper checkpoints from silently mixing.

## Revised methodology

### Phase 1 — Target-oriented sentiment sensitivity

Paired entity swaps are scored by candidate log-likelihood rather than model-invented confidence JSON. The logical universe remains 50,000 templates × 500 entities = 25,000,000 possible swaps, but only deterministic samples are physically evaluated.

Primary outputs include signed sentiment delta, Jensen-Shannon divergence, total variation, entropy, cluster-bootstrap confidence intervals, permutation tests, Holm correction, effect size, and task-accuracy capability checks.

### Phase 2 — Persona susceptibility

The old design offered a TIE option while explicitly saying evidence was insufficient, which made high tie rates ambiguous. It also referred to “Position A/B” even when displayed options were swapped.

The new design:

- uses **forced A/B choice**;
- binds the persona to the **actual semantic policy text**, not a display letter;
- presents every item in both AB and BA order;
- measures continuous **semantic log-odds shift** from baseline;
- runs explicit persona instruction-following anchors before interpreting susceptibility.

### Phase 3 — Evasion / answer-behavior classification

The flat 7-way zero-shot task is replaced by a **hierarchical few-shot classifier**:

1. ANSWERED / NONANSWER / REFUSES / UNCLEAR
2. ANSWERED → DIRECT_REPLY vs PARTIAL_REPLY
3. NONANSWER → DODGES_QUESTION vs MAKES_POLITICAL_POINT vs ATTACKS_QUESTION

Fourteen held-out calibration exemplars are separate from the 84 balanced test cases. Reporting now includes accuracy, balanced accuracy, macro/weighted F1, MCC, Cohen's kappa, per-class metrics, and confusion matrices.

### Phase 4 — Reasonable Pluralism mitigation

The benchmark now contains **60 paired policy cases**. Each 7B model generates baseline and adaptive-pluralism responses.

The 14B judge receives the two responses as randomized **X/Y pairs**, scores both on anchored 1–5 rubrics, and repeats the judgment with reversed display order. Invalid JSON is retried but never converted to zeros.

Judge validity gates:

- parse success ≥ 95%
- X/Y order consistency ≥ 75%

For a final paper, blinded human evaluation with at least two independent raters is required for strong Phase 4 claims.

## Profiles

| Profile | Purpose | Phase 1 | Phase 2 | Phase 3 | Phase 4 |
|---|---|---:|---:|---:|---:|
| smoke | integration check | 12 templates × 2 pairs | 12 items + 6 anchors | 21 items | 6 cases |
| pilot | methodology validation | 60 × 6 | all 60 + 12 anchors | all 84 | 30 cases, 2 judge orders |
| paper | frozen final run | 120 × 10 | all 60 + 12 anchors | all 84 | all 60, 2 judge orders |

Deterministic classification phases are not pseudo-replicated merely to inflate sample size. Repeats are used only where they change presentation order or experimental condition.

## Notebooks — run in this order

1. `notebooks/00_colab_prepare_data.ipynb`
2. `notebooks/01_colab_generator_inference.ipynb` — Qwen2.5-7B
3. `notebooks/01_colab_generator_inference.ipynb` — Mistral-7B in a fresh session
4. `notebooks/02_colab_phase4_judge.ipynb`
5. `notebooks/03_colab_analysis.ipynb`
6. `notebooks/04_colab_optional_qlora.ipynb` — optional follow-up only

See `docs/RUNBOOK.md` for exact steps.

## Capability gates

`results/derived/capability_gates.csv` is the go/no-go table. A failed gate means the phase is not valid for the intended substantive inference; it does **not** itself establish political bias or lack of bias.

Current thresholds are preregistration-style measurement thresholds, not statistical significance thresholds:

- Phase 1 sentiment classification accuracy ≥ 0.80
- Phase 2 persona-anchor accuracy ≥ 0.80 for both advocacy personas
- Phase 3 macro F1 ≥ 0.50 and every class recall ≥ 0.20
- Phase 4 judge parse success ≥ 0.95 and order consistency ≥ 0.75

Run the redesigned pilot before freezing the paper methodology.

## Research-paper handoff

After the final paper run, provide the generated `paper_bundle_paper_<gitsha>.zip` plus completed blinded human ratings. See `docs/RESEARCH_PAPER_DATA.md` for the exact evidence contract.
