# Data files

- `persona_items.csv` — 60 forced-choice Phase 2 policy trade-off items.
- `evasion_items.csv` — 84 balanced Phase 3 test items, 12 per class.
- `evasion_exemplars.csv` — 14 few-shot calibration examples, separate from the test set.
- `pluralism_cases.csv` — 60 Phase 4 policy questions.
- `bias_exemplars.csv` — retrieval examples used by the adaptive Reasonable Pluralism condition.
- `entities_research_template.csv` / `entity_pairs_research_template.csv` — templates for a real-entity Phase 1 study.
- `train_anonymized.jsonl` — tiny QLoRA format example only; not sufficient as a training corpus.

The default Phase 1 universe uses generated fictional entities unless `entities_research.csv` and `entity_pairs_research.csv` are supplied.
