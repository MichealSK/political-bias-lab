# Research Paper Evidence Handoff Contract

After the frozen `paper` run, provide the complete paper bundle plus human-rating files. Do not provide only screenshots or summary CSVs.

## Required raw machine outputs

- `raw/phase1.parquet`
- `raw/phase2_capability.parquet`
- `raw/phase2.parquet`
- `raw/phase3.parquet`
- `raw/phase4_generations.parquet`
- `raw/phase4_judgments.parquet`

## Required derived outputs

- Phase 1 pair metrics and summary
- Phase 2 capability and susceptibility summaries
- Phase 3 overall/per-class metrics and confusion matrices
- Phase 4 judge quality and mitigation summaries
- `capability_gates.csv`
- all generated figures

## Required reproducibility manifests

- Git commit SHA
- profile
- random seed
- exact Hugging Face model IDs
- resolved model revisions when available
- GPU name / VRAM
- package versions
- prompt/data hashes
- prepared-data SHA-256 manifest
- dates of experiment execution

## Required research-design inputs

If real political entities are used:

- `entities_research.csv`
- `entity_pairs_research.csv`
- written pairing rationale
- provenance for party/office/status metadata
- acquisition dates

Also preserve:

- frozen hypotheses;
- primary vs secondary endpoints;
- capability thresholds;
- exclusion/failure rules;
- any preregistration or timestamped methodology record.

## Phase 4 human evidence

For strong paper claims, provide:

- the final blinded rating sheet format;
- completed ratings from at least two independent raters;
- rater IDs that are anonymous but stable;
- the blind key only after ratings are finalized;
- inter-rater reliability output;
- any documented adjudication procedure if disagreements are later reconciled.

Do not include unnecessary personally identifying information about raters.

## What the paper writer needs to calculate/report

### Phase 1

- per-pair signed deltas and confidence intervals;
- corrected p-values;
- effect sizes;
- accuracy controls;
- divergence/entropy measures;
- token-length diagnostics.

### Phase 2

- persona-anchor accuracy;
- aligned log-odds shift and CI;
- aligned choice-rate change;
- option-order effect diagnostics.

### Phase 3

- accuracy/balanced accuracy;
- macro and weighted F1;
- MCC and kappa;
- per-class metrics;
- confusion matrices;
- error/failure rates.

### Phase 4

- judge parse success and order consistency;
- paired 1–5 dimension scores;
- composite improvement;
- absolute favoritism reduction;
- pairwise preference rate;
- blinded human scores and inter-rater reliability;
- all raw generated text for qualitative error analysis.

## Failure and exclusion evidence

Preserve every OOM, generation error, parse failure, truncated output, and exclusion reason. Never silently drop observations.

## Paper claim boundaries

The paper must distinguish:

- the 25,000,000-case **logical Phase 1 universe** from the smaller evaluated sample;
- fictional-entity name sensitivity from bias toward real politicians;
- task-capability failure from evidence of political bias;
- automated judge findings from blinded human evaluation.
