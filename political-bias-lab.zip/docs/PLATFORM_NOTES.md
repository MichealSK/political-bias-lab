# Platform Notes — Google Colab Only

The project no longer uses Kaggle.

## Why the workload is split across notebooks

Free Colab GPU type, quota, and runtime duration are not guaranteed. Therefore the project does not assume one continuous session can run the entire experiment.

The two 7B generators and the 14B judge are run in separate sessions, while all checkpoints persist in Google Drive.

## GPU preflight

Every GPU notebook checks CUDA availability and reported GPU VRAM before model loading.

Configured minimums:

- 7B generators: about 10 GB reported VRAM
- 14B judge: about 14 GB reported VRAM

These checks reduce avoidable OOM failures but cannot guarantee that a particular Colab allocation will fit every workload.

## Quantization

Models use bitsandbytes 4-bit NF4 with double quantization. BF16 compute is selected when the GPU supports it; otherwise FP16 is used.

## Persistence

Prepared data and results are symlinked into:

```text
/content/drive/MyDrive/political-bias-lab/runs/<profile>-<gitsha>/
```

This prevents profile/revision contamination and allows safe resume after Colab disconnects.
