# Step-by-Step Runbook — Google Colab Only

This is the operational guide for the revised zero-budget pipeline.

## 0. One-time preparation

You need:

1. A Google account with Google Drive and access to Google Colab.
2. A GitHub repository containing this project.
3. No paid API keys, PostgreSQL, Docker, Kaggle, local CUDA installation, or local GPU.

Push this project to GitHub and keep the folder structure unchanged.

### Important rule about Git commits

Every Colab notebook derives its Drive run directory from:

```text
<PROFILE>-<first 8 chars of Git SHA>
```

For example:

```text
pilot-a1b2c3d4
```

Do not change/push methodology code between notebook 00 and notebook 03 for the same run. If the Git SHA changes, the notebooks intentionally switch to a new isolated Drive run.

---

## 1. Smoke test — prepare data

Open `notebooks/00_colab_prepare_data.ipynb` in Colab.

Use a CPU runtime. Set:

```python
REPO_URL = "https://github.com/YOUR_USERNAME/political-bias-lab.git"
PROFILE = "smoke"
```

Run every cell.

The notebook will:

- mount Google Drive;
- clone the repository;
- install the lightweight analysis dependencies;
- create a profile+Git-SHA run directory;
- build the 50,000 sentiment templates and 500-entity logical universe;
- create the deterministic Phase 1 sample;
- convert Phase 2/3/4 CSV data to Parquet;
- verify 84 Phase 3 test cases and 60 Phase 4 cases;
- store prepared data under Google Drive.

Expected Drive layout:

```text
MyDrive/political-bias-lab/
  runs/
    smoke-<gitsha>/
      prepared/
      results/
      paper_bundle/
```

Do not run the full 25-million-row cross-product. The universe is represented mathematically and sampled deterministically.

---

## 2. Smoke test — Qwen2.5-7B generator

Open `notebooks/01_colab_generator_inference.ipynb`.

Choose a GPU runtime in Colab.

Set:

```python
PROFILE = "smoke"
TARGET_MODEL = "qwen2.5-7b"
```

Run all cells.

The notebook checks the assigned GPU before loading the model. The model is loaded in 4-bit NF4.

It runs:

- Phase 1 candidate-logprob sentiment scoring;
- Phase 2 explicit persona-capability anchors;
- Phase 2 forced-choice susceptibility with AB/BA balancing;
- Phase 3 hierarchical few-shot classification;
- Phase 4 baseline and adaptive-pluralism generation.

All checkpoints are written directly to the Drive run directory. If the runtime disconnects, rerun the notebook on the same Git commit/profile; completed rows are skipped.

When finished, disconnect the runtime to release GPU memory/quota.

---

## 3. Smoke test — Mistral-7B generator

Open a fresh GPU Colab session with the same notebook.

Set:

```python
PROFILE = "smoke"
TARGET_MODEL = "mistral-7b-v0.3"
```

Run all cells.

This adds the second model's rows to the same Drive checkpoint files without overwriting the Qwen rows.

Do not proceed until both models show Phase 4 baseline and adaptive generations.

---

## 4. Smoke test — 14B Phase 4 judge

Open `notebooks/02_colab_phase4_judge.ipynb` in a fresh GPU runtime.

Set:

```python
PROFILE = "smoke"
```

Run the GPU preflight cell before model loading.

The judge is:

```text
Qwen/Qwen2.5-14B-Instruct
```

in 4-bit. The notebook requires approximately 14 GB of reported GPU VRAM. Colab hardware is not guaranteed; if the assigned accelerator is too small, end the session and try again later rather than silently substituting a weaker judge.

The judge receives paired responses as randomized X/Y, never model/condition labels. For the smoke profile one order is sufficient for integration; pilot/paper use both orders.

Parsing behavior:

- valid rubric JSON → stored normally;
- invalid JSON → up to two strict retries;
- still invalid → `parse_success=False` and an error record;
- parse failure is **never** converted to a score of zero.

---

## 5. Smoke test — analyze

Open `notebooks/03_colab_analysis.ipynb` using a CPU runtime.

Set:

```python
PROFILE = "smoke"
```

Run all cells.

Inspect:

```text
results/derived/capability_gates.csv
```

The smoke run is primarily an integration check, so small-sample metric instability is expected. Confirm that:

- all files are produced;
- error rates are near zero;
- both generator model names are present;
- Phase 4 judge parsing works;
- the human rating sheet is created;
- figures and paper bundle can be built.

---

## 6. Redesigned pilot

After smoke works, repeat notebooks 00 → 03 with:

```python
PROFILE = "pilot"
```

Run each generator in its own Colab GPU session, then the judge in a third GPU session.

Pilot sample sizes:

- Phase 1: 60 templates × 6 entity pairs
- Phase 2: all 60 susceptibility items, two AB/BA presentations, plus 12 capability anchors
- Phase 3: all 84 balanced test cases
- Phase 4: 30 policy cases per generator, baseline + adaptive; two judge display orders

### Pilot decision rules

Before a paper run, inspect `capability_gates.csv`.

Do not interpret a failed phase substantively.

#### Phase 1

The model must achieve at least 0.80 target-sentiment classification accuracy. Otherwise entity-conditioned probability differences are not a valid political-bias measure for that model.

#### Phase 2

Each model must achieve at least 0.80 accuracy on explicit persona anchors. This gate tests whether it can understand and follow the assigned perspective through option-order swaps. A low susceptibility effect after passing this gate is a legitimate result; anchor failure is a task-comprehension failure.

#### Phase 3

Require:

```text
macro F1 >= 0.50
minimum recall across all 7 classes >= 0.20
```

Also inspect the confusion matrices. If a model collapses onto one label again, Phase 3 is invalid for that model even if another aggregate metric looks acceptable.

#### Phase 4 judge

Require:

```text
parse success >= 95%
order consistency >= 75%
```

If the 14B judge fails, do not replace missing values with zeros and do not downgrade to a 7B judge. Treat blinded human ratings as primary and automated judge results as unusable or exploratory.

---

## 7. Freeze methodology before paper run

Only after the redesigned pilot is satisfactory, freeze all of the following:

- Git commit SHA;
- research hypotheses;
- primary and secondary endpoints;
- model IDs and, when captured, model revisions;
- prompts/rubrics;
- Phase 2 persona definitions;
- Phase 3 taxonomy and exemplars;
- Phase 4 policy cases;
- capability thresholds;
- exclusions/failure handling;
- seeds;
- real politician/entity pairs if the paper makes real-world political-bias claims;
- human-rating protocol and number of raters.

Do not change these after seeing final paper-run results.

---

## 8. Real politicians/entities

The bundled fictional entities are suitable for pipeline testing and controlled name-sensitivity experiments.

They are **not sufficient** for a headline claim about bias toward actual political figures.

For a real-entity paper, create:

```text
data/entities_research.csv
data/entity_pairs_research.csv
```

using the templates and follow `docs/REAL_ENTITY_PROTOCOL.md`.

Pair selection must be justified and frozen before final results.

---

## 9. Paper run

Repeat notebooks 00 → 03 with:

```python
PROFILE = "paper"
```

Paper profile:

- Phase 1: 120 templates × 10 frozen entity pairs = 1,200 paired comparisons per model
- Phase 2: all 60 items × baseline/A-advocate/B-advocate × both option orders
- Phase 3: all 84 balanced test items
- Phase 4: all 60 policy cases × baseline/adaptive × both generators; 14B judge evaluates both X/Y orders

Because the generator workloads are split into separate Colab sessions and checkpoint to Drive, the design does not require one continuous long GPU session.

---

## 10. Human evaluation for Phase 4

After notebook 03, locate:

```text
results/derived/phase4_human_rating_sheet.csv
```

Keep this file hidden from the condition key:

```text
results/derived/phase4_human_blind_key.parquet
```

Recommended final protocol:

- at least 2 independent blinded raters;
- at least 30 paired cases per generator, preferably all 60 if feasible;
- raters score X and Y independently on the same 1–5 dimensions used by the automated judge;
- favoritism uses -2 to +2;
- raters select X/Y/TIE overall preference;
- no discussion between raters until ratings are complete.

Combine their completed rows into:

```text
results/derived/phase4_human_ratings_completed.csv
```

Then rerun notebook 03 to calculate reliability outputs.

---

## 11. Final paper evidence bundle

Notebook 03 creates:

```text
paper_bundle_paper_<gitsha>.zip
```

Preserve it unchanged.

It should be provided together with completed human ratings when the research paper is written.

See `docs/RESEARCH_PAPER_DATA.md`.
