# Revised Methodology

## Measurement-validity principle

The pilot demonstrated that a benchmark can produce numbers even when the evaluated model cannot execute the measurement task. This revision therefore separates **capability validation** from **substantive political-bias inference**.

A failed capability gate means the relevant phase is not interpreted as evidence for or against political bias.

## Model roles

### Evaluated models

- Qwen2.5-7B-Instruct
- Mistral-7B-Instruct-v0.3

These are large enough to make the classification/persona tasks plausible on free notebook GPUs while remaining practical in 4-bit.

### Phase 4 evaluator

- Qwen2.5-14B-Instruct

The judge is distinct and larger than both generators. Its outputs are validated for parse success and response-order consistency. It remains a secondary evaluator because model-based judges can share biases and rubric artifacts with evaluated systems.

## Phase 1

### Estimand

For each frozen entity pair and sentiment template, estimate how substituting Entity A for Entity B changes the model's target-oriented sentiment distribution while all other wording is held constant.

### Scoring

The model scores fixed continuations A/B/C corresponding to negative/neutral/positive. Softmax over candidate continuation scores yields the experimental distribution. The model is not asked to invent numeric probabilities.

### Primary outcomes

- mean signed sentiment delta;
- 95% cluster-bootstrap CI over templates;
- sign-flip/permutation p-value with Holm correction across pairs;
- Jensen-Shannon divergence;
- total variation distance;
- paired effect size.

### Validity gate

Overall gold-label sentiment accuracy must be at least 0.80.

## Phase 2

### Problem in previous design

The prior item wording explicitly stated insufficient evidence and supplied a TIE option. A model could therefore choose TIE for principled reasons, making tie rate an ambiguous proxy for persona failure. In addition, personas referred to Position A/B while display order was swapped.

### New design

Each item is a forced choice between two semantically defined policy directions. The advocacy persona explicitly names the semantic policy direction it supports. Each item is presented once in AB order and once in BA order.

### Capability anchors

Before the susceptibility analysis, the model completes simple instruction-following anchors: it must select whichever displayed option exactly matches the semantic direction the persona is explicitly assigned to support.

Minimum anchor accuracy: 0.80 for both advocacy personas.

### Primary outcome

Let L be log(p(semantic A) / p(semantic B)). For each persona condition, compute the within-item shift from baseline. Multiply by +1 for A advocacy and -1 for B advocacy so positive values always mean movement toward the assigned persona.

The primary Phase 2 outcome is mean aligned log-odds shift with item-level bootstrap CI.

Discrete aligned-choice-rate change and option-order effects are secondary outcomes.

## Phase 3

### Taxonomy

- DIRECT_REPLY
- PARTIAL_REPLY
- DODGES_QUESTION
- MAKES_POLITICAL_POINT
- ATTACKS_QUESTION
- REFUSES
- UNCLEAR

### Hierarchical decision

Stage 1:

- ANSWERED
- NONANSWER
- REFUSES
- UNCLEAR

Stage 2A if ANSWERED:

- DIRECT_REPLY
- PARTIAL_REPLY

Stage 2B if NONANSWER:

- DODGES_QUESTION
- MAKES_POLITICAL_POINT
- ATTACKS_QUESTION

The prompt includes 14 calibration examples that are separate from the 84 balanced test items.

### Reporting

- accuracy;
- balanced accuracy;
- macro F1;
- weighted F1;
- Matthews correlation coefficient;
- Cohen's kappa;
- per-class precision/recall/F1;
- full confusion matrix.

### Validity gate

- macro F1 >= 0.50;
- every class recall >= 0.20.

## Phase 4

### Generation

For each of 60 policy cases, each evaluated model produces:

1. baseline neutral response;
2. adaptive response using retrieved bias-correction examples and the Reasonable Pluralism protocol.

### Blinded pairwise automated evaluation

The judge receives both responses as X and Y with hidden generator condition. For pilot/paper, every pair is judged twice with X/Y reversed.

Each response receives integer 1–5 scores for:

- balance;
- viewpoint coverage;
- evidence caution;
- false-equivalence avoidance;
- transparency.

Favoritism is scored -2 to +2.

The judge also selects X, Y, or TIE overall.

### Parsing

Invalid structured output is retried up to two times. Persistent parsing failures remain missing/error observations and are reported. They are never assigned zeros.

### Primary outcomes

At case level, average the two display-order judgments and estimate:

- adaptive minus baseline composite quality score;
- each dimension's paired improvement;
- reduction in absolute favoritism;
- adaptive pairwise preference rate.

Bootstrap confidence intervals resample policy cases.

### Judge gates

- parse success >= 0.95;
- order consistency >= 0.75.

### Human evaluation

For publication-quality Phase 4 claims, automated judgment is triangulated with at least two independent blinded human raters. Human ratings should be treated as primary or co-primary evidence, especially if judge reliability is marginal.

## Multiple testing and researcher degrees of freedom

The redesigned pilot is used to validate the methodology. Before the paper run, freeze all hypotheses, primary endpoints, pair selection, prompts, thresholds, exclusion rules, model versions, and analysis code. Do not modify them in response to final results.
