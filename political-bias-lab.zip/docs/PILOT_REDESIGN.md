# Pilot Failure → Methodology Redesign

This document records why the methodology changed after the first pilot. Preserve it as part of the research audit trail.

## Observed pilot failures

The first pilot used Qwen2.5-1.5B-Instruct and SmolLM2-1.7B-Instruct.

Observed problems included:

- Phase 3 collapse toward `PARTIAL_REPLY`, including near-single-class behavior from SmolLM2;
- inability to distinguish subtle `DODGES_QUESTION` and `ATTACKS_QUESTION` cases reliably;
- Phase 4 judge outputs that produced unusable/zero rubric scores;
- Phase 2 tie-heavy/contradictory behavior.

These results showed that the benchmark was confounding the substantive construct with model task capability.

## Changes made

### Models

Replaced 1.5B–1.7B evaluated models with two 7B-class open models and moved Phase 4 judging to a separate 14B model.

### Phase 2

The pilot interpretation was not solely a model-size problem. The old task itself encouraged ties by saying no outcome evidence was available and offering a tie option. It also created ambiguity when semantic Position A/B and displayed A/B were swapped.

The redesign removes the tie response, binds personas to policy text, balances display order, uses log-odds shifts, and adds explicit instruction-following anchors.

### Phase 3

Replaced flat seven-way zero-shot classification with hierarchical few-shot classification and added separate calibration examples. Expanded reporting beyond macro F1 to include balanced accuracy, MCC, kappa, per-class recall, and confusion matrices.

### Phase 4

Expanded the benchmark from 24 to 60 policy cases. Replaced cross-judging by the evaluated small models with a distinct 14B judge. The judge compares blinded X/Y pairs, uses anchored 1–5 integer rubrics, reverses response order, retries malformed JSON, and reports parser/order reliability before scores are interpreted.

Blinded human evaluation is required for strong final claims.

### Infrastructure

Removed Kaggle entirely. Every step now runs in Google Colab and persists to Google Drive.

Runs are isolated by profile + Git commit SHA to prevent stale checkpoint contamination.

### Replication

Deterministic model-scoring calls are no longer repeated merely to increase `n`. Repeats are retained only for meaningful presentation manipulations such as AB/BA option order or X/Y judge order.

## Interpretation rule

The redesigned pilot must pass capability gates before a final paper run is frozen. If a phase still fails after the redesign, that phase should be revised again or removed from substantive claims; its failure must not be reframed as evidence of political bias.
