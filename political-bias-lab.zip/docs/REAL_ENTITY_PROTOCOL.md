# Real-Entity Protocol for a Paper Claiming Political Bias

The repository runs by default with fictional names. That is suitable for testing the pipeline and studying generic name sensitivity.

A stronger paper about **political bias toward real politicians** requires a separate real-entity protocol.

## Required entity columns

Create `data/entities_research.csv` with:

```text
entity_id
display_name
entity_type
entity_group
country
is_real
active
source
as_of_date
```

Recommended additional fields:

```text
party
ideological_family
office_status
gender_metadata_if_research_relevant
name_language
name_tokenization_notes
public_prominence_tier
```

Only include attributes that are methodologically justified.

## Pair file

Create `data/entity_pairs_research.csv`:

```text
pair_id
pair_name
entity_a_id
entity_b_id
pair_kind
pair_rationale
```

## Pairing rules should be fixed before final inference

Possible defensible matching factors include:

- same country/political system;
- similar office level;
- similar period of prominence;
- comparable electoral relevance;
- explicit opposite-party or ideological comparison when that is the hypothesis;
- documented prominence matching;
- pre-registered inclusion/exclusion criteria.

Avoid choosing pairs because pilot outputs looked interesting.

## Familiarity confound

A model may treat a famous politician differently from an obscure one because the name is more represented in training data, not because of ideology.

Consider:

- prominence matching;
- fictional-name controls;
- token-length controls;
- multiple figures per ideological group;
- hierarchical analysis by country/party/family instead of one celebrity pair.

## Current-office status

If office status matters to the study, record an explicit `as_of_date` and source.

Do not rely on a paper reader assuming that today's role/status was also true when inference was run.

## Claim discipline

These conclusions have different strength:

1. "The model's classifier is sensitive to entity names." — weakest, directly supported by counterfactual swaps.
2. "The model systematically favors one member of these pre-specified pairs." — stronger.
3. "The model systematically favors an ideological/party group." — requires multiple people/pairs and group-level analysis.
4. "The model has general political bias." — broadest and hardest to justify.

Do not jump from 1 to 4.
